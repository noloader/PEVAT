// Placed in public domain by Jeffrey Walton, noloader@gmail.com
// Distribute freely, and don't worry about encumbered licenses. 
// Bug fixes to noloader@gmail.com are encouraged. Public
// acknowledgement is welcomed but not required. Attribution
// must remain (sorry).

#include "stdafx.h"

#include "Windows.h"
#include "Aclapi.h"
#include <StrSafe.h>

// If you are taking the time to protect the process, you realize the default DACL
// on a process is relatively weak. Please also take the time to harden the DACL on
// all threads . The code is nearly the same, except (1) open the thread rather than
// the process, and (2) the constants which make up 'poison' are different. See
// http://www.microsoft.com/whdc/system/vista/process_vista.mspx.

void DaclInfo();
void Pause(const char* message);
DWORD ProtectProcess();

int main(int /*argc*/, char* /*argv*/[])
{
	do
	{
		// DaclInfo();

		Pause("Ready to add deny ACE. Press [ENTER] to continue.\n");

		DWORD d = ProtectProcess();
		if(d != ERROR_SUCCESS) {
			cerr << "Unable to protect process." << endl;
			break;
		}

		// DaclInfo();

		Pause("Added deny ACE. Inspect with your favotite tool.\nPress [ENTER] to continue.\n");

	} while(false);

	return 0;
}

void DaclInfo()
{
	PSECURITY_DESCRIPTOR pSD = NULL;

	__try
	{
		DWORD dwResult;
		PACL pDacl = NULL;

		dwResult = GetSecurityInfo(
			GetCurrentProcess(),
			SE_KERNEL_OBJECT, // process object
			DACL_SECURITY_INFORMATION,
			NULL, // owner
			NULL, // group
			&pDacl, // dacl
			NULL, // sacl
			&pSD);
		if(dwResult != ERROR_SUCCESS) { __leave; }

		BOOL bResult;
		SECURITY_DESCRIPTOR_CONTROL control;
		DWORD dwRev;

		bResult = GetSecurityDescriptorControl(pSD, &control, &dwRev);
		if(FALSE == bResult) { __leave; }

		if((control & SE_DACL_PRESENT) && (control & SE_DACL_DEFAULTED)) {
			cout << "DACL Info: Default DACL is present" << endl;
		} else if((control & SE_DACL_PRESENT)) {
			cout << "DACL Info: Non-default DACL is present" << endl;
		} else {
			cout << "DACL Info: No DACL, control = 0x" << std::hex << control << endl;
		}
	}

	__finally
	{
		if(pSD) {
			LocalFree(pSD);
			pSD = NULL;
		}
	}
}

DWORD ProtectProcess()
{
	// Returned to caller
	DWORD dwResult = (DWORD)-1;

	// Released on exit
	HANDLE hToken = NULL;
	PVOID pTokenInfo = NULL;

	PSID psidEveryone = NULL;
	PSID psidSystem = NULL;
	PSID psidAdmins = NULL;

	PACL pDacl = NULL;
	PSECURITY_DESCRIPTOR pSecDesc = NULL;

	__try
	{
		// Scratch
		DWORD dwSize = 0;
		BOOL bResult = FALSE;

		// Try to fetch the current user. We *don't* use OpenThreadToken in case
		// the thread is impersonating. If this is a well known service, it should
		// be acceptable to hard code a user.
		if(!OpenProcessToken(GetCurrentProcess(), TOKEN_READ, &hToken)) {
			dwResult = GetLastError();
			assert(FALSE);
			__leave; /*failed*/
		}

		bResult = GetTokenInformation(hToken, TokenUser, NULL, 0, &dwSize);
		dwResult = GetLastError();
		assert(bResult == FALSE && ERROR_INSUFFICIENT_BUFFER == dwResult);
		if(!(bResult == FALSE && ERROR_INSUFFICIENT_BUFFER == dwResult)) { __leave; /*failed*/ }

		if(dwSize) {
			pTokenInfo = HeapAlloc(GetProcessHeap(),0,dwSize);
			dwResult = GetLastError();
			assert(NULL != pTokenInfo);
			if(NULL == pTokenInfo) { __leave; /*failed*/ }
		}

		bResult = GetTokenInformation(hToken, TokenUser, pTokenInfo, dwSize, &dwSize);
		dwResult = GetLastError();
		assert(bResult && pTokenInfo);
		if(!(bResult && pTokenInfo)) { __leave; /*failed*/ }

		PTOKEN_USER pTokenUser = (TOKEN_USER*)pTokenInfo;
		// SID_AND_ATTRIBUTES cannot be null
		// assert(NULL != pTokenUser->User);

		PSID psidCurUser = pTokenUser->User.Sid;
		assert(NULL != psidCurUser);
		if(!psidCurUser) { __leave; /*failed*/ }

		SID_IDENTIFIER_AUTHORITY sidEveryone = SECURITY_WORLD_SID_AUTHORITY;
		bResult = AllocateAndInitializeSid(&sidEveryone, 1,
			SECURITY_WORLD_RID, 0, 0, 0, 0, 0, 0, 0, &psidEveryone);
		dwResult = GetLastError();
		assert(bResult && psidEveryone);
		if(!(bResult && psidEveryone)) { __leave; /*failed*/ }

		SID_IDENTIFIER_AUTHORITY sidSystem = SECURITY_NT_AUTHORITY;
		bResult = AllocateAndInitializeSid(&sidSystem, 1,
			SECURITY_LOCAL_SYSTEM_RID, 0, 0, 0, 0, 0, 0, 0, &psidSystem);
		dwResult = GetLastError();
		assert(bResult && psidSystem);
		if(!(bResult && psidSystem)) { __leave; /*failed*/ }

		SID_IDENTIFIER_AUTHORITY sidAdministrators = SECURITY_NT_AUTHORITY;
		bResult = AllocateAndInitializeSid(&sidAdministrators, 2,
			SECURITY_BUILTIN_DOMAIN_RID, DOMAIN_ALIAS_RID_ADMINS,
			0, 0, 0, 0, 0, 0, &psidAdmins);
		dwResult = GetLastError();
		assert(bResult && psidAdmins);
		if(!(bResult && psidAdmins)) { __leave; /*failed*/ }

		const PSID psidArray[] = {
			psidEveryone,	/* Deny most rights to everyone */
			psidCurUser,	/* Allow what was not denied */
			psidSystem,		/* Full control */
			psidAdmins,		/* Full control */
		};

		// Determine required size of the ACL
		dwSize = sizeof(ACL);

		// First the DENY, then the ALLOW
		dwSize += GetLengthSid(psidArray[0]);
		dwSize += sizeof(ACCESS_DENIED_ACE) - sizeof(DWORD);

		for(UINT i=1; i<_countof(psidArray); i++ ) {
			// DWORD is the SidStart field, which is not used for absolute format
			dwSize += GetLengthSid(psidArray[i]);
			dwSize += sizeof(ACCESS_ALLOWED_ACE) - sizeof(DWORD);
		}

		pDacl = (PACL)HeapAlloc(GetProcessHeap(),0,dwSize);
		dwResult = GetLastError();
		assert(NULL != pDacl);
		if(NULL == pDacl) { __leave; /*failed*/ }

		bResult = InitializeAcl(pDacl,dwSize,ACL_REVISION);
		dwResult = GetLastError();
		assert(TRUE == bResult);
		if(FALSE == bResult) { __leave; /*failed*/ }

		// Mimic Protected Process
		// http://www.microsoft.com/whdc/system/vista/process_vista.mspx
		// Protected processes allow PROCESS_TERMINATE, which is
		// probably not appropriate for high integrity software.
		static const DWORD dwPoison =
			/*READ_CONTROL |*/ WRITE_DAC | WRITE_OWNER |
			PROCESS_CREATE_PROCESS | PROCESS_CREATE_THREAD |
			PROCESS_DUP_HANDLE | PROCESS_QUERY_INFORMATION |
			PROCESS_SET_QUOTA | PROCESS_SET_INFORMATION |
			PROCESS_VM_OPERATION | PROCESS_VM_READ | PROCESS_VM_WRITE |
			// In addition to protected process
			PROCESS_SUSPEND_RESUME | PROCESS_TERMINATE;
		bResult = AddAccessDeniedAce(pDacl, ACL_REVISION, dwPoison, psidArray[0]);
		dwResult = GetLastError();
		assert(TRUE == bResult);
		if(FALSE == bResult) { __leave; /*failed*/ }

		// Standard and specific rights not explicitly denied
		static const DWORD dwAllowed = ~dwPoison & 0x1FFF;
		bResult = AddAccessAllowedAce(pDacl, ACL_REVISION, dwAllowed, psidArray[1]);
		dwResult = GetLastError();
		assert(TRUE == bResult);
		if(FALSE == bResult) { __leave; /*failed*/ }

		// Because of ACE ordering and Microsoft's access check algorithm, System will
		// effectively have dwAllowed even though the ACE specifies PROCESS_ALL_ACCESS
		// (unless software uses SeDebugPrivilege or SeTcbName and increases access).
		// As an exercise, check behavior of tools such as Process Explorer under XP,
		// Vista, and above. Vista and above should exhibit slightly different behavior
		// due to slightly different algorithmic behavior and Restricted tokens.
		bResult = AddAccessAllowedAce(pDacl, ACL_REVISION,PROCESS_ALL_ACCESS, psidArray[2]);
		dwResult = GetLastError();
		assert(TRUE == bResult);
		if(FALSE == bResult) { __leave; /*failed*/ }

		// Because of ACE ordering and Microsoft's access check algorithm, Administrators
		// will effectively have dwAllowed even though the ACE specifies PROCESS_ALL_ACCESS
		// (unless the Administrator invokes 'discretionary security' by taking ownership and
		// increasing access). As an exercise, check behavior of tools such as Process Explorer
		// under XP, Vista, and above. Vista and above should exhibit slightly different behavior
		// due to slightly different algorithmic behavior and Restricted tokens.
		bResult = AddAccessAllowedAce(pDacl, ACL_REVISION,PROCESS_ALL_ACCESS, psidArray[3]);
		dwResult = GetLastError();
		assert(TRUE == bResult);
		if(FALSE == bResult) { __leave; /*failed*/ }

		pSecDesc = (PSECURITY_DESCRIPTOR)HeapAlloc(GetProcessHeap(),0,SECURITY_DESCRIPTOR_MIN_LENGTH);
		dwResult = GetLastError();
		assert(NULL != pSecDesc);
		if(NULL == pSecDesc) { __leave; /*failed*/ }

		// InitializeSecurityDescriptor initializes a security descriptor in
		// absolute format, rather than self-relative format. See
		// http://msdn.microsoft.com/en-us/library/aa378863(VS.85).aspx
		bResult = InitializeSecurityDescriptor(pSecDesc, SECURITY_DESCRIPTOR_REVISION);
		dwResult = GetLastError();
		assert(TRUE == bResult);
		if(FALSE == bResult) { __leave; /*failed*/ }

		bResult = SetSecurityDescriptorDacl(pSecDesc, TRUE, pDacl, FALSE);
		dwResult = GetLastError();
		assert(TRUE == bResult);
		if(FALSE == bResult) { __leave; /*failed*/ }

		// It would be helpful if we could set the Owner SID to NULL or a
		// non-existant group since the owner can always modify the token.
		// If we ditch ownership (ie, the current user is no longer the owner)
		// it helps ensure the bad guy cannot open our process token.
		// Under Vista, we setting the the owner to Administrators results in
		// ERROR_INVALID_OWNER.
		dwResult = SetSecurityInfo(
			GetCurrentProcess(),
			SE_KERNEL_OBJECT, // process object
			OWNER_SECURITY_INFORMATION | DACL_SECURITY_INFORMATION,
			psidCurUser, // Owner SID
			NULL, // Group SID
			pDacl,
			NULL // SACL
			);
		dwResult = GetLastError();
		assert(ERROR_SUCCESS == dwResult);
		if(ERROR_SUCCESS != dwResult) { __leave; /*failed*/ }

		dwResult = ERROR_SUCCESS;
	}
	__finally
	{
		if(NULL != pSecDesc) {
			HeapFree(GetProcessHeap(),0,pSecDesc);
			pSecDesc = NULL;
		}
		if(NULL != pDacl) {
			HeapFree(GetProcessHeap(),0,pDacl);
			pDacl = NULL;
		}
		if(psidAdmins) {
			FreeSid(psidAdmins);
			psidAdmins = NULL;
		}
		if(psidSystem) {
			FreeSid(psidSystem);
			psidSystem = NULL;
		}
		if(psidEveryone) {
			FreeSid(psidEveryone);
			psidEveryone = NULL;
		}
		if(NULL != pTokenInfo) {
			HeapFree(GetProcessHeap(),0,pTokenInfo);
			pTokenInfo = NULL;
		}
		if(NULL != hToken) {
			CloseHandle(hToken);
			hToken = NULL;
		}
	}

	SetLastError(dwResult);
	return dwResult;
}

void Pause(const char* message)
{
	cin.clear();
	cout << message;
	cin.ignore((streamsize)numeric_limits<streamsize>::max, '\n');
}
