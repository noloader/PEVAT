// Placed in public domain by Jeffrey Walton, noloader@gmail.com
// Distribute freely, and don't worry about encumbered licenses. 
// Bug fixes to noloader@gmail.com are encouraged. Public
// acknowledgement is welcomed but not required. Attribution
// must remain (sorry).

#pragma once

#include "targetver.h"

#include <iostream>
using std::cin;
using std::cerr;
using std::cout;
using std::endl;
using std::streamsize;

#include <limits>
using std::numeric_limits;

#include <assert.h>
