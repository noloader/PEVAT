// Placed in public domain by Jeffrey Walton, noloader@gmail.com
// Distribute freely, and don't worry about encumbered licenses. 
// Bug fixes to noloader@gmail.com are encouraged. Public
// acknowledgement is welcomed but not required. Attribution
// must remain (sorry).

#include "stdafx.h"

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file
